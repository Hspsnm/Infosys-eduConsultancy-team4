package com.example.eduHub_user_registration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EduHubBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
